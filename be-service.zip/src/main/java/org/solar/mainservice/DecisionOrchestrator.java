package org.solar.mainservice;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.solar.mainservice.ai.dto.AiPredictResponse;
import org.solar.mainservice.dto.StateChangeEventDTO;
import org.solar.mainservice.safety.SafetyGuard;
import org.solar.mainservice.service.SimulatorRelay;
import org.solar.mainservice.websocket.WebSocketNotifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class DecisionOrchestrator {

    private final SimulatorRelay simulatorRelay;
    private final WebSocketNotifier webSocketNotifier;
    private final SafetyGuard safetyGuard;
    private final Environment env;

    private SafetyGuard.Commands prev;

    public Mono<Void> handlePrediction(String sessionId,
                                       String panelId,
                                       String prevMode,                   // ← NUEVO
                                       Map<String, Object> prevParams,
                                       AiPredictResponse pr,
                                       boolean applyControl) {

        log.info("[ORCH] IN session={} panel={} applyControl={} pr={}", sessionId, panelId, applyControl, pr);

        webSocketNotifier.sendRuntimeEvent("ai_prediction", Map.of(
                "sessionId", sessionId,
                "panelId", panelId,
                "prediction", pr
        ), sessionId, null);

        if (!applyControl || pr.getProposedCommands() == null || pr.getProposedCommands().isEmpty()) {
            log.info("[ORCH] SKIP control (applyControl={} or no commands)", applyControl);
            return Mono.empty();
        }

        var limits = SafetyGuard.Limits.builder()
                .rpmMin(env.getProperty("control.limits.rpmMin", Double.class, 300.0))
                .rpmMax(env.getProperty("control.limits.rpmMax", Double.class, 1000.0))
                .flowMin(env.getProperty("control.limits.flowMin", Double.class, 0.0))
                .flowMax(env.getProperty("control.limits.flowMax", Double.class, 1.8))
                .pressMin(env.getProperty("control.limits.pressMin", Double.class, 0.0))
                .pressMax(env.getProperty("control.limits.pressMax", Double.class, 3.2))
                .detPctMax(env.getProperty("control.limits.detPctMax", Double.class, 0.05))
                .maxDeltaRpm(env.getProperty("control.limits.maxDeltaRpm", Double.class, 120.0))
                .build();

        List<String> safetyNotes = new ArrayList<>();
        SafetyGuard.Commands applied = safetyGuard.projectSafe(pr.getProposedCommands(), limits, prev, safetyNotes);
        prev = applied;

        Map<String, Object> nextParams = new HashMap<>();
        nextParams.put("brushRpm", applied.getBrushRpm());
        nextParams.put("waterPressure", applied.getNozzlePressureBar());
        nextParams.put("waterFlow", applied.getWaterFlowLpm());
        double detPct = applied.getDetergentPct(); // % 0..1 (convierte a LPM si tu sim lo necesita)
        nextParams.put("detergentFlowRate", detPct);
        nextParams.put("robotSpeed", 0.35);
        nextParams.put("passOverlap", 0.3);
        nextParams.put("dwellTime", applied.getDwellSec());

        if ("now".equalsIgnoreCase(pr.getRecommendedCleaningFrequency())) {
            bumpFloor(nextParams, "brushRpm", 700d);
            bumpFloor(nextParams, "waterPressure", 1.2d);
            bumpFloor(nextParams, "waterFlow", 0.9d);
        }

        // Cause y nextMode
        String cause = "AI_DECISION";
        String nextMode = (prevMode != null) ? prevMode : "AUTO";
        if ("now".equalsIgnoreCase(pr.getRecommendedCleaningFrequency())) {
            cause = "AI_NOW";
            nextMode = "CLEANING";
        } else if ("hold_20s".equalsIgnoreCase(pr.getRecommendedCleaningFrequency())) {
            cause = "AI_HOLD";
            // puedes dejar el mismo modo o "HOLD" si tu sim lo reconoce
        }

        // Construcción correcta de prev/next (ModeRef)
        StateChangeEventDTO.ModeRef prevRef = null;
        if (prevMode != null && !prevMode.isBlank()) {
            prevRef = new StateChangeEventDTO.ModeRef(); prevRef.setMode(prevMode);
        }
        StateChangeEventDTO.ModeRef nextRef = new StateChangeEventDTO.ModeRef(); nextRef.setMode(nextMode);

        StateChangeEventDTO evt = new StateChangeEventDTO();
        evt.setType("param_change"); // ⬅️ clave: no "state_change"
        evt.setSessionId(sessionId);
        evt.setPanelId(panelId);
        evt.setCause(cause);
        evt.setTimestamp(LocalDateTime.now());
        evt.setPrev(prevRef);                 // ← ahora es ModeRef
        evt.setNext(nextRef);                 // ← ahora es ModeRef
        evt.setParamsTarget(nextParams);  // ⬅️ necesario para que el Relay construya body.params

        return simulatorRelay.relay(evt)
                .doOnSuccess(r -> webSocketNotifier.sendRuntimeEvent("ai_decision", Map.of(
                        "sessionId", sessionId,
                        "proposed", pr.getProposedCommands(),
                        "applied", applied,
                        "notes", safetyNotes,
                        "explain", pr.getExplain()
                ), sessionId, null))
                .then();

    }

    private void bumpFloor(Map<String, Object> m, String k, Double floor) {
        Object v = m.get(k);
        if (v instanceof Number) {
            double cur = ((Number) v).doubleValue();
            if (cur < floor) m.put(k, floor);
        }
    }
}