package org.solar.mainservice.safety;

import lombok.Builder;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class SafetyGuard {

    @Data @Builder
    public static class Limits {
        private double rpmMin;
        private double rpmMax;
        private double flowMin;
        private double flowMax;
        private double pressMin;
        private double pressMax;
        private double detPctMax;
        private double maxDeltaRpm;
    }

    @Data @Builder
    public static class Commands {
        private double brushRpm;
        private double waterFlowLpm;
        private double nozzlePressureBar;
        private int    passes;
        private double detergentPct;
        private String route;
        private int    dwellSec;
    }

    /** proposed: {brushRpm, waterFlow, pressure, passes, detergentPct, route{...}} en 0..1 */
    public Commands projectSafe(Map<String, Object> proposed, Limits lim, Commands prev, List<String> notes) {
        double rpm01   = get01(proposed, "brushRpm");
        double flow01  = get01(proposed, "waterFlow");
        double press01 = get01(proposed, "pressure");
        double pass01  = get01(proposed, "passes");
        double det01   = get01(proposed, "detergentPct");

        double rpm   = lerp(lim.rpmMin,   lim.rpmMax,   rpm01);
        double flow  = lerp(lim.flowMin,  lim.flowMax,  flow01);
        double press = lerp(lim.pressMin, lim.pressMax, press01);
        int    passes = (int) Math.round(lerp(0, 3, pass01));
        double det   = lerp(0, lim.detPctMax, det01);

        // Rate limit en RPM
        if (prev != null && Math.abs(rpm - prev.brushRpm) > lim.maxDeltaRpm) {
            rpm = prev.brushRpm + Math.signum(rpm - prev.brushRpm) * lim.maxDeltaRpm;
            notes.add("rate_limited_rpm");
        }

        // Cierres por límites duros
        flow  = clamp(flow,  lim.flowMin,  lim.flowMax);
        press = clamp(press, lim.pressMin, lim.pressMax);
        det   = clamp(det,   0, lim.detPctMax);

        String route = "keep";
        Object r = proposed.get("route");
        if (r instanceof Map) {
            route = ((Map<String, Double>) r).entrySet()
                    .stream().max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey).orElse("keep");
        }

        return Commands.builder()
                .brushRpm(rpm)
                .waterFlowLpm(flow)
                .nozzlePressureBar(press)
                .passes(passes)
                .detergentPct(det)
                .route(route)
                .dwellSec(0)
                .build();
    }

    private static double get01(Map<String,Object> m, String k) {
        return Optional.ofNullable(m.get(k))
                .filter(Number.class::isInstance)
                .map(Number.class::cast)
                .map(Number::doubleValue)
                .map(v -> clamp(v,0,1))
                .orElse(0.0);
    }

    private static double lerp(double lo, double hi, double x01){ return lo + (hi - lo) * clamp(x01,0,1); }
    private static double clamp(double v, double lo, double hi){ return Math.max(lo, Math.min(hi, v)); }
}