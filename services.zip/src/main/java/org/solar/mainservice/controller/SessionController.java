package org.solar.mainservice.controller;

import lombok.RequiredArgsConstructor;
import org.solar.mainservice.model.Session;
import org.solar.mainservice.service.SessionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api/sessions")
@RequiredArgsConstructor
public class SessionController {

    private final SessionService sessionService;

    @GetMapping("/active")
    public Flux<Session> getActiveSessions() {
        return sessionService.getActiveSessions();
    }
}
