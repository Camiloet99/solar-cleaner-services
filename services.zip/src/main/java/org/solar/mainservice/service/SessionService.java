package org.solar.mainservice.service;

import lombok.RequiredArgsConstructor;
import org.solar.mainservice.model.Session;
import org.solar.mainservice.repository.SessionRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

@Service
@RequiredArgsConstructor
public class SessionService {

    private final SessionRepository sessionRepository;

    public Flux<Session> getActiveSessions() {
        return sessionRepository.findByStatus("active");
    }
}

