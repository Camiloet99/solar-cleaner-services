package org.solar.mainservice.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "sessions")
@Data
public class Session {
    @Id
    private String id;
    private String panelId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status; // "active", "completed", etc.
}
